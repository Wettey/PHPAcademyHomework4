create definer = root@localhost trigger soldier_after_war
    after update
    on battle
    for each row
BEGIN
        UPDATE soldier SET active = 0
            WHERE faction = 2;
    END;

